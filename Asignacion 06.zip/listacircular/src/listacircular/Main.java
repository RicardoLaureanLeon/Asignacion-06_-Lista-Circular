package listacircular;

class Nodo {
    int dato;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
        this.anterior = null;
    }
}

class ListaCircularDoble {
    private Nodo cabeza;
    private Nodo cola;
    private Nodo iterador;

    public ListaCircularDoble() {
        cabeza = null;
        cola = null;
        iterador = null;
    }

    public void agregar(int dato) {
        Nodo nuevo = new Nodo(dato);

        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
            cabeza.siguiente = cabeza;
            cabeza.anterior = cabeza;
            iterador = cabeza;
        } else {
            cola.siguiente = nuevo;
            nuevo.anterior = cola;
            nuevo.siguiente = cabeza;
            cabeza.anterior = nuevo;
            cola = nuevo;
        }
    }

    public void mostrarLista() {
        if (cabeza == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        System.out.print("Estado de la lista: ");
        Nodo temporal = cabeza;
        do {
            System.out.print("[" + temporal.dato + "] <-> ");
            temporal = temporal.siguiente;
        } while (temporal != cabeza);
        System.out.println("(Vuelve al inicio: " + cabeza.dato + ")");
    }

    public void irInicio() {
        if (cabeza != null) {
            iterador = cabeza;
            System.out.println("-> irInicio(): Iterador en la CABEZA. Valor: " + iterador.dato);
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    public void irFinal() {
        if (cola != null) {
            iterador = cola;
            System.out.println("-> irFinal(): Iterador en la COLA. Valor: " + iterador.dato);
        } else {
            System.out.println("La lista está vacía.");
        }
    }

    public void previous() {
        if (iterador != null) {
            iterador = iterador.anterior;
            System.out.println("-> previous(): Retrocedimos un nodo. Valor: " + iterador.dato);
        }
    }
    
    public void next() {
        if (iterador != null) {
            iterador = iterador.siguiente;
            System.out.println("-> next(): Avanzamos un nodo. Valor: " + iterador.dato);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        ListaCircularDoble lista = new ListaCircularDoble();

        System.out.println("=== LISTA CIRCULAR DOBLEMENTE ENLAZADA ===\n");
        lista.agregar(10);
        lista.agregar(20);
        lista.agregar(30);
        lista.agregar(40);

        lista.mostrarLista();
        System.out.println("-----------------------------------------------------");

        lista.irInicio();
        
        System.out.println("\n[!] Prueba de circularidad hacia atrás (de Cabeza a Cola):");
        lista.previous(); 
        
        System.out.println("\n[!] Vamos al final:");
        lista.irFinal(); 
        
        System.out.println("\n[!] Prueba de circularidad hacia adelante (de Cola a Cabeza):");
        lista.next(); 

        System.out.println("\n[!] Recorriendo toda la lista en reversa con previous():");
        lista.irFinal();  
        lista.previous(); 
        lista.previous(); 
        lista.previous(); 
        lista.previous(); 
    }
}